import { useEffect, useRef, useState } from 'react';
import { Animated, Text, TextStyle, StyleProp } from 'react-native';
import { motion, type } from '../lib/theme';
import { useReducedMotion } from '../lib/motion';

// Counts up to a number when it first shows or changes, e.g. revenue tiles.
// <AnimatedNumber value={1450} format={TTD} />
export default function AnimatedNumber({ value, format = (n) => String(Math.round(n)), style }:
  { value: number; format?: (n: number) => string; style?: StyleProp<TextStyle> }) {
  const reduced = useReducedMotion();
  const anim = useRef(new Animated.Value(0)).current;
  const [shown, setShown] = useState(reduced ? value : 0);

  useEffect(() => {
    if (reduced) { setShown(value); return; }
    const id = anim.addListener(({ value: v }) => setShown(v));
    Animated.timing(anim, { toValue: value, duration: motion.countUp, useNativeDriver: false }).start(() => setShown(value));
    return () => anim.removeListener(id);
  }, [value, reduced]);

  return <Text style={[type.number, style]} accessibilityLabel={format(value)}>{format(shown)}</Text>;
}
