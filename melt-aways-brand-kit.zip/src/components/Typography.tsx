import { Text, TextProps } from 'react-native';
import { type } from '../lib/theme';

// Brand text styles. Use these instead of plain <Text> so fonts stay consistent.
const make = (style: object) => ({ style: extra, ...rest }: TextProps) => <Text style={[style, extra]} {...rest} />;

export const Greeting = make(type.greeting);   // Great Vibes script
export const Title = make(type.title);         // Playfair Bold: screen titles
export const Heading = make(type.heading);     // Playfair SemiBold: section headings
export const Body = make(type.body);           // Lato: everyday text
export const BodyStrong = make(type.bodyStrong);
export const Label = make(type.label);         // small grey labels above values
export const Small = make(type.small);
